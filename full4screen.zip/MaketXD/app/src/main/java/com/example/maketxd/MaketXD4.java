package com.example.maketxd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class MaketXD4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maket_x_d4);
        ImageView gallery = (ImageView) findViewById(R.id.imageView4);
    }
    public void Gallery(android.view.View view) {
        Intent intent = new Intent( MaketXD4.this, MaketXD3.class);
        startActivity(intent);
    }
}